const db = require("../config/database");

const ArticleModel = {
  getAll: () => {
    return new Promise((resolve, reject) => {
      db.all(`SELECT * FROM articles ORDER BY created_at DESC`, [], (err, rows) => {
        if (err) reject(err);
        else resolve(rows.map(r => ({ ...r, tags: JSON.parse(r.tags) })));
      });
    });
  },

  getById: (id) => {
    return new Promise((resolve, reject) => {
      db.get(`SELECT * FROM articles WHERE id = ?`, [id], (err, row) => {
        if (err) reject(err);
        else if (!row) resolve(null);
        else resolve({ ...row, tags: JSON.parse(row.tags) });
      });
    });
  },

  create: (article) => {
    return new Promise((resolve, reject) => {
      const { id, title, content, category, tags, created_by } = article;
      db.run(
        `INSERT INTO articles (id, title, content, category, tags, created_by) VALUES (?, ?, ?, ?, ?, ?)`,
        [id, title, content, category, JSON.stringify(tags || []), created_by],
        function (err) {
          if (err) reject(err);
          else resolve({ id, title, content, category, tags });
        }
      );
    });
  },

  update: (id, article) => {
    return new Promise((resolve, reject) => {
      const { title, content, category, tags } = article;
      db.run(
        `UPDATE articles SET title = ?, content = ?, category = ?, tags = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [title, content, category, JSON.stringify(tags || []), id],
        function (err) {
          if (err) reject(err);
          else resolve({ id, title, content, category, tags });
        }
      );
    });
  },

  delete: (id) => {
    return new Promise((resolve, reject) => {
      db.run(`DELETE FROM articles WHERE id = ?`, [id], function (err) {
        if (err) reject(err);
        else resolve({ deleted: id });
      });
    });
  }
};

module.exports = ArticleModel;