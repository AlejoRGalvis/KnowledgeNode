const db = require("../config/database");

const UserModel = {
  createUser: (username, passwordHash, role = "viewer") => {
    return new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)`,
        [username, passwordHash, role],
        function (err) {
          if (err) reject(err);
          else resolve({ id: this.lastID, username, role });
        }
      );
    });
  },

  findByUsername: (username) => {
    return new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM users WHERE username = ?`,
        [username],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  }
};

module.exports = UserModel;