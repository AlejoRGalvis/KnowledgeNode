const express = require("express");
const router = express.Router();
const ArticleController = require("../controllers/articleController");
const authMiddleware = require("../middleware/authMiddleware");

router.get("/", ArticleController.getAll);
router.get("/:id", ArticleController.getById);
router.post("/", authMiddleware, ArticleController.create);
router.put("/:id", authMiddleware, ArticleController.update);
router.delete("/:id", authMiddleware, ArticleController.delete);

module.exports = router;