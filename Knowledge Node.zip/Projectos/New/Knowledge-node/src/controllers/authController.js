const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const UserModel = require("../models/userModel");
const db = require("../config/database");

const SECRET = process.env.JWT_SECRET || "knowledge_node_secret";

const AuthController = {
  register: async (req, res) => {
    try {
      const { username, password, role } = req.body;

      if (!username || !password) {
        return res.status(400).json({ error: "Username and password required" });
      }

      const existing = await UserModel.findByUsername(username);
      if (existing) {
        return res.status(400).json({ error: "User already exists" });
      }

      const passwordHash = await bcrypt.hash(password, 10);
      const user = await UserModel.createUser(username, passwordHash, role);

      res.json({ message: "User created", user });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  login: async (req, res) => {
    try {
      const { username, password } = req.body;

      const user = await UserModel.findByUsername(username);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role },
        SECRET,
        { expiresIn: "8h" }
      );

      res.json({ token, role: user.role, username: user.username });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  changePassword: async (req, res) => {
    try {
      const { username, newPassword } = req.body;

      if (!username || !newPassword) {
        return res.status(400).json({ error: "Username and new password required" });
      }

      const user = await UserModel.findByUsername(username);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const passwordHash = await bcrypt.hash(newPassword, 10);

      await new Promise((resolve, reject) => {
        db.run(
          `UPDATE users SET password_hash = ? WHERE username = ?`,
          [passwordHash, username],
          function(err) {
            if (err) reject(err);
            else resolve();
          }
        );
      });

      res.json({ message: "Password updated successfully" });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};

module.exports = AuthController;