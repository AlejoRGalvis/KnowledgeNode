const ArticleModel = require("../models/articleModel");
const { v4: uuidv4 } = require("uuid");

const ArticleController = {
  getAll: async (req, res) => {
    try {
      const articles = await ArticleModel.getAll();
      res.json(articles);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  getById: async (req, res) => {
    try {
      const article = await ArticleModel.getById(req.params.id);
      if (!article) return res.status(404).json({ error: "Article not found" });
      res.json(article);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  create: async (req, res) => {
    try {
      const { title, content, category, tags } = req.body;
      if (!title || !content || !category) {
        return res.status(400).json({ error: "Title, content and category required" });
      }
      const article = await ArticleModel.create({
        id: uuidv4(),
        title,
        content,
        category,
        tags,
        created_by: req.user.username
      });
      res.json(article);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  update: async (req, res) => {
    try {
      const { title, content, category, tags } = req.body;
      const existing = await ArticleModel.getById(req.params.id);
      if (!existing) return res.status(404).json({ error: "Article not found" });
      const article = await ArticleModel.update(req.params.id, { title, content, category, tags });
      res.json(article);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  delete: async (req, res) => {
    try {
      const existing = await ArticleModel.getById(req.params.id);
      if (!existing) return res.status(404).json({ error: "Article not found" });
      await ArticleModel.delete(req.params.id);
      res.json({ message: "Article deleted" });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};

module.exports = ArticleController;