const db = require('./src/config/database');
const { v4: uuidv4 } = require('uuid');

const articles = [
  // D2D
  {
    id: uuidv4(),
    title: 'Funds Transfer',
    category: 'D2D',
    tags: JSON.stringify(['D2D', 'Funds', 'Transfer', 'Payment']),
    content: '<h1>Funds Transfer</h1><p>Process for executing a funds transfer between accounts through the door-to-door channel.</p><h2>Requirements</h2><ul><li>Valid client ID</li><li>Source and destination account numbers</li><li>Transfer amount within daily limits</li></ul><h2>Steps</h2><ul><li>Verify client identity</li><li>Confirm account details</li><li>Process transfer in system</li><li>Issue confirmation receipt</li></ul>',
    created_by: 'admin'
  },
  {
    id: uuidv4(),
    title: 'Bill Payment',
    category: 'D2D',
    tags: JSON.stringify(['D2D', 'Bill', 'Payment', 'Collection']),
    content: '<h1>Bill Payment</h1><p>Process for collecting bill payments from clients at their location through the D2D channel.</p><h2>Accepted Payment Types</h2><ul><li>Utilities</li><li>Credit card bills</li><li>Loan installments</li><li>Insurance premiums</li></ul><h2>Steps</h2><ul><li>Verify bill details</li><li>Collect payment</li><li>Process in system</li><li>Provide receipt</li></ul>',
    created_by: 'admin'
  },

  // RC
  {
    id: uuidv4(),
    title: 'Lost/Stolen Card',
    category: 'RC',
    tags: JSON.stringify(['RC', 'Lost', 'Stolen', 'Replacement', 'Card']),
    content: '<h1>Lost/Stolen Card</h1><p>Process for handling lost or stolen revolving credit cards and issuing replacements.</p><h2>Immediate Actions</h2><ul><li>Block the card immediately upon report</li><li>Verify client identity</li><li>Review last transactions for fraud</li></ul><h2>Replacement Process</h2><ul><li>Issue temporary card if needed</li><li>Order permanent replacement</li><li>Update client contact information</li><li>Set up fraud alerts</li></ul>',
    created_by: 'admin'
  },
  {
    id: uuidv4(),
    title: 'Balance Transfer',
    category: 'RC',
    tags: JSON.stringify(['RC', 'Balance', 'Transfer', 'Credit']),
    content: '<h1>Balance Transfer</h1><p>Process for transferring outstanding balances from external credit cards to a Scotiabank revolving credit account.</p><h2>Eligibility</h2><ul><li>Account must be active and in good standing</li><li>Available credit must cover transfer amount</li><li>Minimum transfer amount: $500</li></ul><h2>Steps</h2><ul><li>Verify available credit limit</li><li>Collect external account details</li><li>Process transfer request</li><li>Confirm completion with client</li></ul>',
    created_by: 'admin'
  },

  // Loans
  {
    id: uuidv4(),
    title: 'Automatic Letters',
    category: 'Loans',
    tags: JSON.stringify(['Loans', 'Letters', 'Automatic', 'Notification']),
    content: '<h1>Automatic Letters</h1><p>Process for generating and managing automatic notification letters for loan accounts.</p><h2>Letter Types</h2><ul><li>Payment reminder letters</li><li>Overdue notices</li><li>Final demand letters</li><li>Account closure notifications</li></ul><h2>System Process</h2><ul><li>System triggers letter based on account status</li><li>Letter generated and queued for dispatch</li><li>Confirmation logged in account history</li></ul>',
    created_by: 'admin'
  },
  {
    id: uuidv4(),
    title: 'SPL Calculator',
    category: 'Loans',
    tags: JSON.stringify(['Loans', 'SPL', 'Calculator', 'Payment']),
    content: '<h1>SPL Calculator</h1><p>Guide for using the Special Payment Loan calculator to determine payment schedules and amounts.</p><h2>Inputs Required</h2><ul><li>Loan principal amount</li><li>Interest rate</li><li>Loan term in months</li><li>Payment frequency</li></ul><h2>Output</h2><ul><li>Monthly payment amount</li><li>Total interest payable</li><li>Full amortization schedule</li></ul><pre style="background:#1a1a2e;color:#00ff88;padding:12px 16px;border-radius:4px;font-family:Courier New,monospace;font-size:12px;border-left:3px solid #00ff88;">SPL CALC PRIN=10000 RATE=5.5 TERM=36\nRESULT: PMT=301.96 TOT-INT=872.56</pre>',
    created_by: 'admin'
  },

  // Disputes
  {
    id: uuidv4(),
    title: 'Vauth Dispute',
    category: 'Disputes',
    tags: JSON.stringify(['Disputes', 'Vauth', 'Authorization', 'Fraud']),
    content: '<h1>Vauth Dispute</h1><p>Process for handling Visa authorization disputes where transactions were incorrectly authorized or processed.</p><h2>Common Vauth Cases</h2><ul><li>Double authorization</li><li>Incorrect authorization amount</li><li>Authorization without purchase</li></ul><h2>Resolution Steps</h2><ul><li>Pull Vauth transaction record</li><li>Compare authorization vs settlement</li><li>File chargeback if applicable</li><li>Credit client account within 5 business days</li></ul>',
    created_by: 'admin'
  },
  {
    id: uuidv4(),
    title: 'Lost/Stolen Dispute',
    category: 'Disputes',
    tags: JSON.stringify(['Disputes', 'Lost', 'Stolen', 'Fraud', 'Chargeback']),
    content: '<h1>Lost/Stolen Dispute</h1><p>Process for handling disputes related to unauthorized transactions on lost or stolen cards.</p><h2>Investigation Steps</h2><ul><li>Confirm card was reported lost/stolen</li><li>Review all transactions after report date</li><li>Identify unauthorized charges</li><li>File fraud claim for each transaction</li></ul><h2>Client Communication</h2><ul><li>Notify client of investigation timeline</li><li>Issue provisional credit within 10 days</li><li>Send resolution letter within 45 days</li></ul>',
    created_by: 'admin'
  },

  // Tsys
  {
    id: uuidv4(),
    title: 'MCHP Process',
    category: 'Tsys',
    tags: JSON.stringify(['Tsys', 'MCHP', 'System', 'Command']),
    content: '<h1>MCHP Process</h1><p>Master Card Hot Card Process — procedure for flagging and blocking compromised Mastercard accounts in Tsys.</p><h2>When to Use</h2><ul><li>Card reported as compromised</li><li>Suspicious activity detected</li><li>Fraud confirmed on account</li></ul><h2>Tsys Commands</h2><pre style="background:#1a1a2e;color:#00ff88;padding:12px 16px;border-radius:4px;font-family:Courier New,monospace;font-size:12px;border-left:3px solid #00ff88;">MCHP ACCT=XXXXXXXXXXXX STAT=H\nVERIFY STATUS ACCT=XXXXXXXXXXXX\nCONFIRM BLOCK=Y DATE=TODAY</pre>',
    created_by: 'admin'
  },
  {
    id: uuidv4(),
    title: 'IFRD Process',
    category: 'Tsys',
    tags: JSON.stringify(['Tsys', 'IFRD', 'Fraud', 'System']),
    content: '<h1>IFRD Process</h1><p>Internal Fraud Detection process in Tsys for identifying and flagging potentially fraudulent accounts.</p><h2>Trigger Conditions</h2><ul><li>Multiple failed PIN attempts</li><li>Transactions in multiple countries within 24hrs</li><li>Unusual spending pattern detected</li></ul><h2>Tsys Commands</h2><pre style="background:#1a1a2e;color:#00ff88;padding:12px 16px;border-radius:4px;font-family:Courier New,monospace;font-size:12px;border-left:3px solid #00ff88;">IFRD ACCT=XXXXXXXXXXXX REVIEW=Y\nFLAG FRAUD=SUSPECTED LEVEL=2\nNOTIFY TEAM=FRAUD-OPS</pre>',
    created_by: 'admin'
  },

  // Management
  {
    id: uuidv4(),
    title: 'Rush Approval',
    category: 'Management',
    tags: JSON.stringify(['Management', 'Rush', 'Approval', 'Escalation']),
    content: '<h1>Rush Approval Process</h1><p>Internal process for expediting approval requests that require immediate management authorization.</p><h2>Eligible Cases</h2><ul><li>High-value transactions above $50,000</li><li>Client escalations requiring same-day resolution</li><li>Regulatory deadline cases</li></ul><h2>Approval Chain</h2><ul><li>Team Lead review — 30 minutes</li><li>Manager sign-off — 1 hour</li><li>Director approval for amounts above $100,000</li></ul><p><strong>Note:</strong> All rush approvals must be documented in the management log.</p>',
    created_by: 'admin'
  },
  {
    id: uuidv4(),
    title: 'Auth Log Review',
    category: 'Management',
    tags: JSON.stringify(['Management', 'Auth', 'Log', 'Review', 'Audit']),
    content: '<h1>Auth Log Review</h1><p>Process for reviewing authorization logs to identify anomalies, patterns, and compliance issues.</p><h2>Review Frequency</h2><ul><li>Daily — automated system checks</li><li>Weekly — team lead manual review</li><li>Monthly — full management audit</li></ul><h2>Key Metrics to Monitor</h2><ul><li>Decline rates by category</li><li>Authorization response times</li><li>Override frequency by agent</li><li>After-hours authorization patterns</li></ul>',
    created_by: 'admin'
  },

  // Consultants
  {
    id: uuidv4(),
    title: 'E-Auth Process',
    category: 'Consultants',
    tags: JSON.stringify(['Consultants', 'E-Auth', 'Electronic', 'Authorization']),
    content: '<h1>E-Auth Process</h1><p>Electronic Authorization process — confidential guide for consultants handling electronic authorization requests.</p><h2>Overview</h2><p>The E-Auth process allows authorized consultants to process electronic authorization requests outside of standard system workflows.</p><h2>Authorization Levels</h2><ul><li>Level A — Standard transactions up to $10,000</li><li>Level B — Enhanced verification for $10,000 - $50,000</li><li>Level C — Director authorization required above $50,000</li></ul><h2>Security Requirements</h2><ul><li>Dual consultant sign-off required</li><li>All E-Auth transactions logged and audited</li><li>Client identity verification mandatory</li></ul><p><strong>Confidential — For authorized consultants only.</strong></p>',
    created_by: 'admin'
  }
];

let done = 0;
articles.forEach(a => {
  db.run(
    'INSERT OR IGNORE INTO articles (id, title, category, tags, content, created_by) VALUES (?, ?, ?, ?, ?, ?)',
    [a.id, a.title, a.category, a.tags, a.content, a.created_by],
    (err) => {
      if (err) console.error('Error:', err.message);
      else console.log('Created:', a.title);
      done++;
      if (done === articles.length) {
        console.log('\nAll articles created successfully!');
        process.exit(0);
      }
    }
  );
});