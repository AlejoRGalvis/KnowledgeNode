const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
require("dotenv").config();

require("./config/database");

const authRoutes = require("./routes/authRoutes");
const articleRoutes = require("./routes/articleRoutes");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(morgan("dev"));
app.use(express.json());

app.use(express.static("public"));

app.use("/api/auth", authRoutes);
app.use("/api/articles", articleRoutes);

app.get("/api/health", (req, res) => {
  res.json({ status: "Server running" });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
