import { useEffect } from "react";

const Index = () => {
  useEffect(() => {
    window.location.href = "/knowledge-node.html";
  }, []);

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #1466e0 0%, #0a40b8 100%)',
      fontFamily: 'Tahoma, Verdana, Arial, sans-serif',
      color: '#fff',
      fontSize: '14px'
    }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: '48px', marginBottom: '16px' }}>📚</div>
        <div style={{ fontWeight: 'bold', fontSize: '18px', marginBottom: '8px' }}>Loading Knowledge Node…</div>
        <div style={{ opacity: 0.8 }}>Redirecting to your encyclopedia…</div>
      </div>
    </div>
  );
};

export default Index;
